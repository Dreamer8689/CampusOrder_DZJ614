package com.dreamer.neusoft.campusorder_dzj614.activity;

import android.app.Activity;
import android.os.Bundle;

import com.dreamer.neusoft.campusorder_dzj614.R;

public class CollectionActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collection);
    }
}
